1) Exv2 Plus it's Working by Python 2.7 only, Download: https://www.python.org/downloads/release/python-2714/
2) Run Crack.py
3) Login by ExV2P.py [username|userkey]
4) Password Login =
    UserName : cracked
    Password  : cracked
5) run by splitter.py, Exmpale:
   Your list: x.txt
   Maximum of every list: 100000
   Your Exploiter : ExV2P.py
   
telegram : @dayak1337